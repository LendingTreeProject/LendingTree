export * from './editCustomer.component';
