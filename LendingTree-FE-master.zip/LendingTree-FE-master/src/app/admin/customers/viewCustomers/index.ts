export * from './viewCustomers.component';
