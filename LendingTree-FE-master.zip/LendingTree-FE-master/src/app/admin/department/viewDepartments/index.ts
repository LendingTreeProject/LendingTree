export * from './viewDepartments.component';
