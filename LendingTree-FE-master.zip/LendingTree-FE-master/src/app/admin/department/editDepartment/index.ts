export * from './editDepartment.component';
