export class LoanType {
  id: number;
  loanType: string;
}
