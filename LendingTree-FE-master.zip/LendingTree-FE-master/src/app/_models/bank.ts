export class Bank {

  id: number;
  bankName: string;
}
