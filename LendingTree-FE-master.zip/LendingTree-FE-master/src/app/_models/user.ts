export class User {
  id: number;
  username: string;
  password: string;
  firstname: string;
  lastname: string;
  email: string;
  salary: number;
  phone: string;
  role: string;
  address: string;
  deptId: number;
}
