export class Employee {
  id: number;
  address: string;
  deptName: string;
  firstname: string;
  lastname: string;
  email: string;

}
