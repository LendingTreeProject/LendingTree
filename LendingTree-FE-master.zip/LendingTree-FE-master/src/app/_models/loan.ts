export class Loan {
  id: number;
  userId: number;
  cusId: number;
  amount: number;
  deptId: number;
  bankId: number;
  loantypeId: number;
  loanstatusId: number;

}
