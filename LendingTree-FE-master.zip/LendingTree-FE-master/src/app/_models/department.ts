export class Department {
  id: number;
  deptName: string;
}
