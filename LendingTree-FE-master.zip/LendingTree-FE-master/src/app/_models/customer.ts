export class Customer {
  id: number;
  salary: number;
  firstname: string;
  lastname: string;
  email: string;
  phone: number;
  password: string;
}
