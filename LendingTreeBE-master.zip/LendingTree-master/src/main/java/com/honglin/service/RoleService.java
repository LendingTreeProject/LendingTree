package com.honglin.service;

import com.honglin.model.entity.Roles;

public interface RoleService {

    Roles getAuthorityById(Integer id);
}
